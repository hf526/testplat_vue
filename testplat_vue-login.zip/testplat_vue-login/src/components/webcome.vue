<template>
  <div>666666</div>
</template>

<script>
export default {
  name: 'webcome'
}
</script>

<style scoped>

</style>
