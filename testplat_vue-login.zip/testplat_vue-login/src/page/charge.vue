<template>
  <div>charge</div>
</template>

<script>
export default {
  name: 'charge'
}
</script>

<style scoped>

</style>
